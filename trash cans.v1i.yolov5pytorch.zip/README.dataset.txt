# trash cans > 2025-07-23 12:21am
https://universe.roboflow.com/sample-detection-othcb/trash-cans-q29ew

Provided by a Roboflow user
License: CC BY 4.0

